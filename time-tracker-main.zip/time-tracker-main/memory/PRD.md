# ChronoFlow — Time Entry & Dashboard

## Original Problem Statement
"I need a time entry software for employees and a dashboard."

## User Choices
- Roles: Employees + Managers/Admins
- Auth: JWT-based custom auth
- Time entry: Both clock in/out and manual entries
- Dashboard: Both personal + admin
- Extras: Projects, CSV export
- (iter 4): All-rate-tiers, PDF invoices, week+month calendar, defer Stripe

## Architecture
- Backend: FastAPI + Motor + MongoDB; JWT (PyJWT + bcrypt); reportlab 4.5.1 for PDF.
- Frontend: React 19 + React Router + Tailwind + shadcn/ui + Recharts; Cabinet Grotesk + IBM Plex Sans.
- Auth: Bearer token from localStorage (cookies set too but secondary, due to platform CORS).

## Implemented
### 2026-02-15 — MVP
- JWT auth, projects, live timer, manual entries, personal + admin dashboards, approval flow, timesheet w/ filters + CSV export, employee directory.

### 2026-02-15 — Iter 2
- Inline edit dialog for entries, bulk approve/reject for admin.

### 2026-02-15 — Iter 4
- ✅ Calendar page with week + month view toggle, prev/today/next navigation, color-coded entry blocks (gray = non-billable).
- ✅ Billable flag on entries (Switch on Manual + Edit dialogs, persisted on backend).
- ✅ Project default_rate + Employee hourly_rate fields with admin-editable inputs.
- ✅ Invoice page: per-project or per-client scope, date range, rate override, employee-rate toggle, live preview table + branded PDF (reportlab).
- ✅ Rate priority: override > employee rate > project default (fallback to employee rate if project default = 0).
- ✅ Only approved + billable entries flow into invoices.

## Test Credentials
- Admin: `admin@chronoflow.com` / `Admin@123`
- Employee: `employee@chronoflow.com` / `Employee@123`

## Backlog
### P1
- Stripe payment links on invoices (next iteration)
- Drag-to-create entries on calendar
- Per-day click on month view to filter timesheet

### P2
- Recurring invoices
- Time-off / leave entries
- Slack/Teams notifications on submission
- Mobile PWA with offline timer

## Next Action Items
1. Stripe integration on invoices (one-click payment link).
2. Drag/click to create entries directly from calendar.
3. Add "Unassigned" client bucket (per testing agent suggestion).
