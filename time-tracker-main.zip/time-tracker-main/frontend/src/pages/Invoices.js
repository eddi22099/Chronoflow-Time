import React, { useEffect, useState } from "react";
import api, { API, formatApiError, minutesToHM } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Download, Eye, Receipt, FileText } from "lucide-react";

export default function Invoices() {
  const [projects, setProjects] = useState([]);
  const [clients, setClients] = useState([]);
  const [form, setForm] = useState({
    scope: "project",
    project_id: "",
    client: "",
    start: "",
    end: "",
    rate_override: "",
    use_employee_rate: false,
    invoice_number: "",
    company_name: "ChronoFlow",
    bill_to: "",
    notes: "",
  });
  const [preview, setPreview] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    Promise.all([api.get("/projects"), api.get("/clients")]).then(([p, c]) => {
      setProjects(p.data);
      setClients(c.data);
    });
  }, []);

  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const buildPayload = () => ({
    scope: form.scope,
    project_id: form.scope === "project" ? form.project_id : undefined,
    client: form.scope === "client" ? form.client : undefined,
    start: form.start ? new Date(form.start).toISOString() : undefined,
    end: form.end ? new Date(`${form.end}T23:59:59`).toISOString() : undefined,
    rate_override: form.rate_override ? parseFloat(form.rate_override) : undefined,
    use_employee_rate: !!form.use_employee_rate,
    invoice_number: form.invoice_number || undefined,
    company_name: form.company_name || "ChronoFlow",
    bill_to: form.bill_to,
    notes: form.notes,
  });

  const doPreview = async () => {
    if (form.scope === "project" && !form.project_id) {
      toast.error("Pick a project");
      return;
    }
    if (form.scope === "client" && !form.client) {
      toast.error("Pick a client");
      return;
    }
    setLoading(true);
    try {
      const { data } = await api.post("/invoices/preview", buildPayload());
      setPreview(data);
    } catch (err) {
      toast.error(formatApiError(err));
    } finally {
      setLoading(false);
    }
  };

  const downloadPdf = async () => {
    if (!preview) await doPreview();
    setLoading(true);
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(`${API}/invoices/generate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(buildPayload()),
      });
      if (!res.ok) throw new Error("PDF failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${form.invoice_number || "invoice"}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Invoice downloaded");
    } catch (err) {
      toast.error("PDF generation failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6" data-testid="invoices-page">
      <header>
        <div className="text-xs uppercase tracking-[0.2em] text-gray-500">Billing</div>
        <h1 className="font-heading text-4xl md:text-5xl font-black tracking-tighter mt-1">Invoices</h1>
        <p className="text-gray-600 mt-2">Convert approved + billable hours into a branded invoice PDF.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="border border-gray-200 p-6 space-y-5" data-testid="invoice-form">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-gray-500 mb-2">Scope</div>
            <div className="flex border border-gray-200 rounded-md overflow-hidden w-fit">
              <button
                type="button"
                onClick={() => update("scope", "project")}
                data-testid="scope-project"
                className={`px-3 py-2 text-xs uppercase tracking-wider font-bold ${form.scope === "project" ? "bg-black text-white" : "bg-white text-gray-600"}`}
              >Project</button>
              <button
                type="button"
                onClick={() => update("scope", "client")}
                data-testid="scope-client"
                className={`px-3 py-2 text-xs uppercase tracking-wider font-bold border-l border-gray-200 ${form.scope === "client" ? "bg-black text-white" : "bg-white text-gray-600"}`}
              >Client</button>
            </div>
          </div>

          {form.scope === "project" ? (
            <div>
              <Label>Project</Label>
              <Select value={form.project_id} onValueChange={(v) => update("project_id", v)}>
                <SelectTrigger data-testid="invoice-project-select"><SelectValue placeholder="Choose a project" /></SelectTrigger>
                <SelectContent>
                  {projects.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name} {p.client ? `· ${p.client}` : ""} {p.default_rate ? `· $${p.default_rate}/h` : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : (
            <div>
              <Label>Client</Label>
              <Select value={form.client} onValueChange={(v) => update("client", v)}>
                <SelectTrigger data-testid="invoice-client-select"><SelectValue placeholder="Choose a client" /></SelectTrigger>
                <SelectContent>
                  {clients.map((c) => (
                    <SelectItem key={c.name} value={c.name}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>From</Label>
              <Input type="date" value={form.start} onChange={(e) => update("start", e.target.value)} data-testid="invoice-start" />
            </div>
            <div>
              <Label>To</Label>
              <Input type="date" value={form.end} onChange={(e) => update("end", e.target.value)} data-testid="invoice-end" />
            </div>
          </div>

          <div className="border border-gray-200 p-4 space-y-3">
            <div className="text-[10px] uppercase tracking-wider text-gray-500 font-bold">Rate strategy</div>
            <p className="text-xs text-gray-600">Priority: override → employee rate → project default.</p>
            <div className="grid grid-cols-2 gap-3 items-end">
              <div>
                <Label>Override rate ($ / hour)</Label>
                <Input type="number" min="0" step="0.01" value={form.rate_override} onChange={(e) => update("rate_override", e.target.value)} placeholder="e.g. 95" data-testid="invoice-rate-override" />
              </div>
              <div className="flex items-center gap-3 mb-1">
                <Switch checked={form.use_employee_rate} onCheckedChange={(v) => update("use_employee_rate", v)} data-testid="invoice-use-employee-rate" />
                <Label className="cursor-pointer">Prefer employee rate</Label>
              </div>
            </div>
          </div>

          <div>
            <Label>Invoice number (auto if blank)</Label>
            <Input value={form.invoice_number} onChange={(e) => update("invoice_number", e.target.value)} placeholder="INV-2026-001" data-testid="invoice-number" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Your company</Label>
              <Input value={form.company_name} onChange={(e) => update("company_name", e.target.value)} data-testid="invoice-company" />
            </div>
            <div>
              <Label>Bill to</Label>
              <Input value={form.bill_to} onChange={(e) => update("bill_to", e.target.value)} placeholder="Client name + address" data-testid="invoice-bill-to" />
            </div>
          </div>
          <div>
            <Label>Notes / payment terms</Label>
            <Textarea value={form.notes} onChange={(e) => update("notes", e.target.value)} placeholder="Net 30. Pay via bank transfer to…" data-testid="invoice-notes" />
          </div>

          <div className="flex gap-2 pt-2">
            <Button onClick={doPreview} disabled={loading} variant="outline" className="border-gray-300 h-10" data-testid="invoice-preview-btn">
              <Eye size={14} className="mr-1.5" /> Preview
            </Button>
            <Button onClick={downloadPdf} disabled={loading} className="bg-black hover:bg-gray-800 text-white h-10" data-testid="invoice-download-btn">
              <Download size={14} className="mr-1.5" /> Download PDF
            </Button>
          </div>
        </section>

        <section className="border border-gray-200 p-6" data-testid="invoice-preview">
          <div className="text-[10px] uppercase tracking-wider text-gray-500 font-bold flex items-center gap-2">
            <Receipt size={12} /> Live preview
          </div>
          {!preview ? (
            <div className="mt-8 text-center text-gray-500 py-16 border border-dashed border-gray-300">
              <FileText className="mx-auto mb-3 text-gray-400" size={28} />
              <div className="font-heading text-lg font-bold">No preview yet</div>
              <p className="text-sm mt-1">Fill the form on the left and click Preview to see line items.</p>
            </div>
          ) : (
            <div className="mt-3 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-heading text-2xl font-black tracking-tighter">{preview.meta.company_name}</div>
                  <div className="text-xs text-gray-500">Bill to: {preview.meta.bill_to}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase tracking-wider text-gray-500">Invoice</div>
                  <div className="font-mono font-bold">#{preview.meta.invoice_number}</div>
                  <div className="text-xs text-gray-500">Issued {preview.meta.issued}</div>
                </div>
              </div>
              <div className="text-xs text-gray-600 font-mono">
                {preview.meta.scope_label} · {preview.meta.period}
              </div>
              <div className="border border-gray-200">
                <table className="w-full text-xs" data-testid="invoice-lines-table">
                  <thead className="bg-gray-900 text-white">
                    <tr>
                      <th className="px-2 py-2 text-left">Date</th>
                      <th className="px-2 py-2 text-left">Employee</th>
                      <th className="px-2 py-2 text-left">Item</th>
                      <th className="px-2 py-2 text-right">Hours</th>
                      <th className="px-2 py-2 text-right">Rate</th>
                      <th className="px-2 py-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.line_items.map((li) => (
                      <tr key={`${li.date}-${li.employee}-${li.project}-${li.task}-${li.amount}`} className="border-b border-gray-100">
                        <td className="px-2 py-1.5 font-mono">{li.date}</td>
                        <td className="px-2 py-1.5">{li.employee}</td>
                        <td className="px-2 py-1.5">{li.project} · {li.task}</td>
                        <td className="px-2 py-1.5 text-right font-mono">{li.hours.toFixed(2)}</td>
                        <td className="px-2 py-1.5 text-right font-mono">${li.rate.toFixed(2)}</td>
                        <td className="px-2 py-1.5 text-right font-mono">${li.amount.toFixed(2)}</td>
                      </tr>
                    ))}
                    {preview.line_items.length === 0 && (
                      <tr><td colSpan={6} className="px-2 py-8 text-center text-gray-500" data-testid="invoice-empty">No approved + billable entries in this range.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
              <div className="flex justify-end gap-8 text-sm">
                <div className="text-right space-y-1">
                  <div className="text-gray-500 text-xs uppercase tracking-wider">Total hours</div>
                  <div className="font-mono">{preview.totals.hours.toFixed(2)}</div>
                </div>
                <div className="text-right space-y-1" data-testid="invoice-total">
                  <div className="text-gray-500 text-xs uppercase tracking-wider">Total due</div>
                  <div className="font-heading text-2xl font-black">${preview.totals.total.toFixed(2)}</div>
                </div>
              </div>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
