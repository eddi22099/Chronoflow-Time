import React, { useEffect, useState } from "react";
import api, { formatApiError } from "@/lib/api";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

function RateCell({ user, onSave }) {
  const [value, setValue] = useState(user.hourly_rate || 0);
  const [saving, setSaving] = useState(false);
  const save = async () => {
    if (parseFloat(value) === parseFloat(user.hourly_rate || 0)) return;
    setSaving(true);
    try {
      await api.patch(`/users/${user.id}`, { hourly_rate: parseFloat(value || 0) });
      toast.success("Rate updated");
      onSave?.();
    } catch (err) {
      toast.error(formatApiError(err));
    } finally {
      setSaving(false);
    }
  };
  return (
    <div className="flex items-center gap-2">
      <span className="text-gray-400 font-mono">$</span>
      <Input
        type="number"
        min="0"
        step="0.01"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onBlur={save}
        disabled={saving}
        data-testid={`rate-input-${user.id}`}
        className="h-8 w-24 font-mono"
      />
      <span className="text-gray-400 font-mono text-xs">/h</span>
    </div>
  );
}

export default function Employees() {
  const [users, setUsers] = useState([]);
  const load = () => api.get("/users").then((r) => setUsers(r.data));
  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-6" data-testid="employees-page">
      <header>
        <div className="text-xs uppercase tracking-[0.2em] text-gray-500">Directory</div>
        <h1 className="font-heading text-4xl md:text-5xl font-black tracking-tighter mt-1">Employees</h1>
        <p className="text-gray-600 mt-2">Everyone on the team. Set hourly rates here — they feed into invoices.</p>
      </header>
      <div className="border border-gray-200 overflow-x-auto">
        <table className="w-full text-sm" data-testid="employees-table">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr className="text-left text-[10px] uppercase tracking-wider text-gray-500">
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Email</th>
              <th className="px-4 py-3">Role</th>
              <th className="px-4 py-3">Hourly rate</th>
              <th className="px-4 py-3">Joined</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-b border-gray-100 row-hover" data-testid={`employee-row-${u.id}`}>
                <td className="px-4 py-3 font-medium">{u.name}</td>
                <td className="px-4 py-3 font-mono text-xs">{u.email}</td>
                <td className="px-4 py-3">
                  <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 border border-gray-300 rounded-sm">{u.role}</span>
                </td>
                <td className="px-4 py-3">
                  <RateCell user={u} onSave={load} />
                </td>
                <td className="px-4 py-3 font-mono text-xs">{u.created_at ? new Date(u.created_at).toLocaleDateString() : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
