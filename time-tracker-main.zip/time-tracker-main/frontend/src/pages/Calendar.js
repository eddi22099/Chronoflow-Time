import React, { useEffect, useMemo, useState } from "react";
import api, { minutesToHM } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronLeft, ChevronRight } from "lucide-react";

const WEEK = "week";
const MONTH = "month";

function startOfWeek(d) {
  const x = new Date(d);
  const day = x.getDay();
  const diff = (day + 6) % 7; // Monday start
  x.setDate(x.getDate() - diff);
  x.setHours(0, 0, 0, 0);
  return x;
}

function startOfMonth(d) {
  const x = new Date(d);
  x.setDate(1);
  x.setHours(0, 0, 0, 0);
  return x;
}

function endOfMonth(d) {
  const x = startOfMonth(d);
  x.setMonth(x.getMonth() + 1);
  x.setMilliseconds(-1);
  return x;
}

function sameDay(a, b) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function fmtMonthYear(d) {
  return d.toLocaleDateString(undefined, { month: "long", year: "numeric" });
}

export default function Calendar() {
  const [mode, setMode] = useState(WEEK);
  const [cursor, setCursor] = useState(new Date());
  const [entries, setEntries] = useState([]);

  const range = useMemo(() => {
    if (mode === WEEK) {
      const s = startOfWeek(cursor);
      const e = new Date(s);
      e.setDate(s.getDate() + 7);
      return { start: s, end: e };
    }
    return { start: startOfMonth(cursor), end: endOfMonth(cursor) };
  }, [mode, cursor]);

  const load = async () => {
    const params = {
      scope: "mine",
      start: range.start.toISOString(),
      end: range.end.toISOString(),
    };
    const { data } = await api.get("/entries", { params });
    setEntries(data);
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [range.start.getTime(), range.end.getTime()]);

  const move = (dir) => {
    const next = new Date(cursor);
    if (mode === WEEK) next.setDate(next.getDate() + 7 * dir);
    else next.setMonth(next.getMonth() + dir);
    setCursor(next);
  };

  const today = () => setCursor(new Date());

  // Build day -> entries map
  const byDay = useMemo(() => {
    const m = {};
    for (const e of entries) {
      const d = new Date(e.start_at);
      const key = d.toDateString();
      (m[key] = m[key] || []).push(e);
    }
    return m;
  }, [entries]);

  const totalMins = useMemo(() => entries.reduce((s, e) => s + (e.duration_minutes || 0), 0), [entries]);

  return (
    <div className="space-y-6" data-testid="calendar-page">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-gray-500">Visual Schedule</div>
          <h1 className="font-heading text-4xl md:text-5xl font-black tracking-tighter mt-1">Calendar</h1>
          <p className="text-gray-600 mt-2">See your tracked time as a grid — by week or month.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex border border-gray-200 rounded-md overflow-hidden" data-testid="calendar-mode-toggle">
            <button
              onClick={() => setMode(WEEK)}
              data-testid="mode-week"
              className={`px-3 py-2 text-xs uppercase tracking-wider font-bold ${mode === WEEK ? "bg-black text-white" : "bg-white text-gray-600 hover:bg-gray-50"}`}
            >Week</button>
            <button
              onClick={() => setMode(MONTH)}
              data-testid="mode-month"
              className={`px-3 py-2 text-xs uppercase tracking-wider font-bold border-l border-gray-200 ${mode === MONTH ? "bg-black text-white" : "bg-white text-gray-600 hover:bg-gray-50"}`}
            >Month</button>
          </div>
        </div>
      </header>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => move(-1)} data-testid="calendar-prev" className="h-9 border-gray-300">
            <ChevronLeft size={14} />
          </Button>
          <Button variant="outline" size="sm" onClick={today} data-testid="calendar-today" className="h-9 border-gray-300 px-3">Today</Button>
          <Button variant="outline" size="sm" onClick={() => move(1)} data-testid="calendar-next" className="h-9 border-gray-300">
            <ChevronRight size={14} />
          </Button>
          <div className="font-heading text-xl font-bold ml-2" data-testid="calendar-title">
            {mode === WEEK
              ? `${range.start.toLocaleDateString(undefined, { month: "short", day: "numeric" })} – ${new Date(range.end.getTime() - 1).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}`
              : fmtMonthYear(cursor)}
          </div>
        </div>
        <div className="text-sm text-gray-600">
          <span className="font-mono text-gray-900 font-semibold" data-testid="calendar-total">{minutesToHM(totalMins)}</span> tracked
        </div>
      </div>

      {mode === WEEK ? <WeekView start={range.start} byDay={byDay} /> : <MonthView cursor={cursor} byDay={byDay} />}
    </div>
  );
}

function WeekView({ start, byDay }) {
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return d;
  });
  const HOURS = Array.from({ length: 24 }, (_, i) => i);

  const today = new Date();

  return (
    <div className="border border-gray-200 overflow-x-auto" data-testid="week-view">
      <div className="grid grid-cols-[60px_repeat(7,minmax(120px,1fr))] min-w-[920px]">
        <div className="border-b border-r border-gray-200 bg-gray-50" />
        {days.map((d) => (
          <div key={d.toISOString()} className={`border-b border-r border-gray-200 px-2 py-2 text-center ${sameDay(d, today) ? "bg-gray-100" : "bg-gray-50"}`}>
            <div className="text-[10px] uppercase tracking-wider text-gray-500">{d.toLocaleDateString(undefined, { weekday: "short" })}</div>
            <div className={`font-heading text-xl font-black tracking-tighter ${sameDay(d, today) ? "text-[#34c759]" : "text-gray-900"}`}>{d.getDate()}</div>
          </div>
        ))}

        {HOURS.map((h) => (
          <React.Fragment key={h}>
            <div className="border-b border-r border-gray-100 h-12 px-2 py-1 text-[10px] font-mono text-gray-400 text-right">
              {h.toString().padStart(2, "0")}:00
            </div>
            {days.map((d) => {
              const cellStart = new Date(d);
              cellStart.setHours(h, 0, 0, 0);
              const cellEnd = new Date(cellStart);
              cellEnd.setHours(cellStart.getHours() + 1);
              const dayEntries = byDay[d.toDateString()] || [];
              const blocks = dayEntries.filter((e) => {
                const s = new Date(e.start_at);
                const en = e.end_at ? new Date(e.end_at) : new Date();
                return s < cellEnd && en > cellStart;
              });
              return (
                <div key={d.toISOString() + h} className="border-b border-r border-gray-100 h-12 relative">
                  {blocks.map((b) => {
                    const s = new Date(b.start_at);
                    const en = b.end_at ? new Date(b.end_at) : new Date();
                    if (s.getHours() !== h || !sameDay(s, d)) return null; // anchor only on starting hour
                    const top = (s.getMinutes() / 60) * 48;
                    const durMin = Math.max(15, ((en - s) / 1000 / 60));
                    const height = (durMin / 60) * 48;
                    return (
                      <div
                        key={b.id}
                        data-testid={`week-block-${b.id}`}
                        className="absolute left-1 right-1 px-1.5 py-1 rounded-sm text-[10px] leading-tight text-white overflow-hidden"
                        style={{ top, height, background: b.billable === false ? "#6b7280" : "#111827", zIndex: 5 }}
                      >
                        <div className="font-semibold truncate">{b.project_name || "—"}</div>
                        <div className="truncate opacity-80">{b.task}</div>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

function MonthView({ cursor, byDay }) {
  const first = startOfMonth(cursor);
  const startGrid = startOfWeek(first);
  const days = Array.from({ length: 42 }, (_, i) => {
    const d = new Date(startGrid);
    d.setDate(startGrid.getDate() + i);
    return d;
  });
  const monthIdx = first.getMonth();
  const today = new Date();

  return (
    <div className="border border-gray-200" data-testid="month-view">
      <div className="grid grid-cols-7 bg-gray-50 border-b border-gray-200">
        {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
          <div key={d} className="px-3 py-2 text-[10px] uppercase tracking-wider text-gray-500 font-bold text-center">{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {days.map((d) => {
          const inMonth = d.getMonth() === monthIdx;
          const entries = byDay[d.toDateString()] || [];
          const mins = entries.reduce((s, e) => s + (e.duration_minutes || 0), 0);
          return (
            <div
              key={d.toISOString()}
              data-testid={`month-cell-${d.toISOString().slice(0, 10)}`}
              className={`border-r border-b border-gray-100 min-h-[110px] p-2 ${inMonth ? "bg-white" : "bg-gray-50/40"}`}
            >
              <div className="flex items-baseline justify-between">
                <div className={`font-heading text-lg font-bold ${sameDay(d, today) ? "text-[#34c759]" : inMonth ? "text-gray-900" : "text-gray-400"}`}>
                  {d.getDate()}
                </div>
                {mins > 0 && (
                  <div className="text-[10px] font-mono text-gray-500">{minutesToHM(mins)}</div>
                )}
              </div>
              <div className="mt-1 space-y-1">
                {entries.slice(0, 3).map((e) => (
                  <div
                    key={e.id}
                    className="text-[10px] truncate px-1.5 py-0.5 rounded-sm text-white"
                    style={{ background: e.billable === false ? "#6b7280" : "#111827" }}
                    data-testid={`month-entry-${e.id}`}
                  >
                    {e.project_name || e.task || "Entry"}
                  </div>
                ))}
                {entries.length > 3 && (
                  <div className="text-[10px] text-gray-500">+{entries.length - 3} more</div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
