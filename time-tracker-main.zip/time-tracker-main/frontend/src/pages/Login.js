import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Clock } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [email, setEmail] = useState("admin@chronoflow.com");
  const [password, setPassword] = useState("Admin@123");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const res = await login(email, password);
    setLoading(false);
    if (res.ok) {
      toast.success(`Welcome back, ${res.user.name}`);
      navigate("/dashboard");
    } else {
      toast.error(res.error);
    }
  };

  return (
    <div className="min-h-screen flex bg-white">
      <div className="hidden lg:flex w-1/2 flex-col justify-between border-r border-gray-200 p-12 bg-grid">
        <div>
          <div className="font-heading text-3xl font-black tracking-tighter">
            CHRONO<span className="text-[#34c759]">FLOW</span>
          </div>
          <div className="text-xs uppercase tracking-[0.2em] text-gray-500 mt-1">Time · Tracked · Together</div>
        </div>
        <div>
          <h1 className="font-heading text-5xl xl:text-6xl font-black tracking-tighter leading-[0.95]">
            Every minute<br /> accounted for.
          </h1>
          <p className="mt-6 text-gray-600 max-w-md leading-relaxed">
            A control-room dashboard for teams who treat their time like the asset it is. Clock in, ship work, prove value.
          </p>
          <div className="mt-12 grid grid-cols-3 gap-4 max-w-md">
            <div className="border border-gray-200 p-4">
              <div className="font-heading text-2xl font-black">12h</div>
              <div className="text-xs uppercase tracking-wider text-gray-500">Avg / day</div>
            </div>
            <div className="border border-gray-200 p-4">
              <div className="font-heading text-2xl font-black">98%</div>
              <div className="text-xs uppercase tracking-wider text-gray-500">Approved</div>
            </div>
            <div className="border border-gray-200 p-4">
              <div className="font-heading text-2xl font-black">0</div>
              <div className="text-xs uppercase tracking-wider text-gray-500">Errors</div>
            </div>
          </div>
        </div>
        <div className="text-xs text-gray-500 font-mono">© ChronoFlow · v1.0</div>
      </div>

      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="lg:hidden font-heading text-2xl font-black mb-8">
            CHRONO<span className="text-[#34c759]">FLOW</span>
          </div>
          <div className="text-xs uppercase tracking-[0.2em] text-gray-500">Welcome back</div>
          <h2 className="font-heading text-3xl sm:text-4xl font-black tracking-tighter mt-1">Sign in to your account</h2>
          <form onSubmit={onSubmit} className="mt-8 space-y-5" data-testid="login-form">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                data-testid="login-email-input"
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                data-testid="login-password-input"
                className="h-11"
              />
            </div>
            <Button
              type="submit"
              disabled={loading}
              data-testid="login-submit-btn"
              className="w-full h-11 bg-black hover:bg-gray-800 text-white"
            >
              {loading ? "Signing in…" : "Sign in"}
            </Button>
          </form>
          <div className="mt-6 text-sm text-gray-600">
            Don&apos;t have an account?{" "}
            <Link to="/register" className="font-semibold underline underline-offset-4" data-testid="link-register">
              Create one
            </Link>
          </div>
          <div className="mt-10 border-t border-gray-200 pt-4 text-xs text-gray-500 font-mono">
            <Clock size={12} className="inline mr-2" />
            Demo admin: admin@chronoflow.com / Admin@123
          </div>
        </div>
      </div>
    </div>
  );
}
