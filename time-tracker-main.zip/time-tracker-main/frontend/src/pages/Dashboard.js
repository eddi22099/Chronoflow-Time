import React, { useEffect, useState } from "react";
import api, { minutesToHM } from "@/lib/api";
import TimerWidget from "@/components/TimerWidget";
import ManualEntryDialog from "@/components/ManualEntryDialog";
import { useAuth } from "@/contexts/AuthContext";
import { Link } from "react-router-dom";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid,
} from "recharts";
import { ArrowRight, Calendar, Clock, ListChecks } from "lucide-react";

function StatTile({ label, value, hint, testId }) {
  return (
    <div className="border border-gray-200 p-5" data-testid={testId}>
      <div className="text-[10px] uppercase tracking-[0.2em] font-bold text-gray-500">{label}</div>
      <div className="font-heading text-3xl lg:text-4xl font-black tracking-tighter mt-2">{value}</div>
      {hint && <div className="text-xs text-gray-500 mt-1 font-mono">{hint}</div>}
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [projects, setProjects] = useState([]);

  const load = async () => {
    const [me, p] = await Promise.all([api.get("/dashboard/me"), api.get("/projects")]);
    setData(me.data);
    setProjects(p.data);
  };

  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-8" data-testid="dashboard-page">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-gray-500">Personal Overview</div>
          <h1 className="font-heading text-4xl md:text-5xl font-black tracking-tighter mt-1">
            Hello, {user?.name?.split(" ")[0]}.
          </h1>
          <p className="text-gray-600 mt-2 max-w-xl">
            Track your hours, manage your projects, and keep your team in the loop. Today is{" "}
            <span className="font-mono text-gray-900">{new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</span>.
          </p>
        </div>
        <ManualEntryDialog projects={projects} onCreated={load} />
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <TimerWidget projects={projects} onChange={load} />
        </div>
        <div className="lg:col-span-2 grid grid-cols-2 gap-4">
          <StatTile label="Today" value={minutesToHM(data?.today_minutes)} testId="stat-today" />
          <StatTile label="This Week" value={minutesToHM(data?.week_minutes)} testId="stat-week" />
          <StatTile label="This Month" value={minutesToHM(data?.month_minutes)} testId="stat-month" />
          <StatTile label="Total Entries" value={data?.total_entries ?? 0} testId="stat-entries" />
        </div>
      </div>

      <section className="border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-[10px] uppercase tracking-[0.2em] font-bold text-gray-500">7-Day Activity</div>
            <h3 className="font-heading text-xl font-bold mt-1">Hours logged this week</h3>
          </div>
        </div>
        <div className="h-56" data-testid="weekly-chart">
          {data?.chart && (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.chart.map((c) => ({ ...c, hours: +(c.minutes / 60).toFixed(2) }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                <XAxis dataKey="day" tick={{ fill: "#6b7280", fontSize: 12 }} axisLine={{ stroke: "#e5e7eb" }} tickLine={false} />
                <YAxis tick={{ fill: "#6b7280", fontSize: 12 }} axisLine={{ stroke: "#e5e7eb" }} tickLine={false} />
                <Tooltip cursor={{ fill: "rgba(0,0,0,0.04)" }} contentStyle={{ borderRadius: 4, border: "1px solid #e5e7eb", fontSize: 12 }} />
                <Bar dataKey="hours" fill="#111827" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-[10px] uppercase tracking-[0.2em] font-bold text-gray-500">Latest</div>
            <h3 className="font-heading text-xl font-bold mt-1">Recent entries</h3>
          </div>
          <Link to="/timesheet" className="text-sm font-medium underline underline-offset-4 inline-flex items-center gap-1" data-testid="link-view-timesheet">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        {data?.recent?.length ? (
          <div className="border border-gray-200">
            <table className="w-full text-sm" data-testid="recent-entries-table">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr className="text-left text-[10px] uppercase tracking-wider text-gray-500">
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Project</th>
                  <th className="px-4 py-3">Task</th>
                  <th className="px-4 py-3">Hours</th>
                  <th className="px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {data.recent.map((e) => (
                  <tr key={e.id} className="border-b border-gray-100 row-hover" data-testid={`recent-row-${e.id}`}>
                    <td className="px-4 py-3 font-mono text-xs">{new Date(e.start_at).toLocaleDateString()}</td>
                    <td className="px-4 py-3">{e.project_name || <span className="text-gray-400">—</span>}</td>
                    <td className="px-4 py-3">{e.task || <span className="text-gray-400">—</span>}</td>
                    <td className="px-4 py-3 font-mono">{minutesToHM(e.duration_minutes)}</td>
                    <td className="px-4 py-3"><StatusPill status={e.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="border border-dashed border-gray-300 p-10 text-center" data-testid="empty-recent">
            <Clock className="mx-auto text-gray-400" size={28} />
            <div className="font-heading text-lg font-bold mt-3">No entries yet</div>
            <p className="text-sm text-gray-500 mt-1">Hit Clock In above or add a manual entry to get started.</p>
          </div>
        )}
      </section>
    </div>
  );
}

export function StatusPill({ status }) {
  const map = {
    approved: "border-[#34c759] text-[#1f7a35] bg-green-50",
    rejected: "border-[#ff3b30] text-[#a31f17] bg-red-50",
    pending: "border-gray-300 text-gray-700 bg-gray-50",
  };
  return (
    <span className={`inline-flex items-center text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 border rounded-sm ${map[status] || map.pending}`}>
      {status}
    </span>
  );
}
