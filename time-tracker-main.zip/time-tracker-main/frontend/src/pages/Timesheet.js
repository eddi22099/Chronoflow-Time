import React, { useEffect, useMemo, useState } from "react";
import api, { API, minutesToHM, formatApiError } from "@/lib/api";
import ManualEntryDialog from "@/components/ManualEntryDialog";
import { StatusPill } from "@/pages/Dashboard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/contexts/AuthContext";
import { Download, Trash2, Pencil } from "lucide-react";
import { toast } from "sonner";
import EditEntryDialog from "@/components/EditEntryDialog";

export default function Timesheet() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [entries, setEntries] = useState([]);
  const [projects, setProjects] = useState([]);
  const [filters, setFilters] = useState({
    start: "",
    end: "",
    project_id: "all",
    status: "all",
    scope: "mine",
  });
  const [editing, setEditing] = useState(null);
  const [editOpen, setEditOpen] = useState(false);

  const load = async () => {
    const params = {};
    if (filters.start) params.start = new Date(filters.start).toISOString();
    if (filters.end) params.end = new Date(`${filters.end}T23:59:59`).toISOString();
    if (filters.project_id !== "all") params.project_id = filters.project_id;
    if (filters.status !== "all") params.status = filters.status;
    params.scope = filters.scope;
    const [e, p] = await Promise.all([
      api.get("/entries", { params }),
      api.get("/projects"),
    ]);
    setEntries(e.data);
    setProjects(p.data);
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [filters]);

  const total = useMemo(() => entries.reduce((s, e) => s + (e.duration_minutes || 0), 0), [entries]);

  const onDelete = async (id) => {
    if (!window.confirm("Delete this entry?")) return;
    try {
      await api.delete(`/entries/${id}`);
      toast.success("Entry deleted");
      load();
    } catch (err) {
      toast.error(formatApiError(err));
    }
  };

  const downloadCsv = async () => {
    try {
      const params = new URLSearchParams();
      params.set("scope", filters.scope);
      if (filters.start) params.set("start", new Date(filters.start).toISOString());
      if (filters.end) params.set("end", new Date(`${filters.end}T23:59:59`).toISOString());
      const token = localStorage.getItem("token");
      const res = await fetch(`${API}/export/csv?${params.toString()}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok) throw new Error("Failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "timesheet.csv";
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      toast.error("Failed to download CSV");
    }
  };

  return (
    <div className="space-y-6" data-testid="timesheet-page">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-gray-500">Records</div>
          <h1 className="font-heading text-4xl md:text-5xl font-black tracking-tighter mt-1">Timesheet</h1>
          <p className="text-gray-600 mt-2">Filter, edit, and export your tracked hours.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={downloadCsv} data-testid="export-csv-btn" variant="outline" className="h-10 border-gray-300">
            <Download size={14} className="mr-1.5" /> Export CSV
          </Button>
          <ManualEntryDialog projects={projects} onCreated={load} />
        </div>
      </header>

      <div className="border border-gray-200 p-4 grid grid-cols-2 md:grid-cols-5 gap-3" data-testid="filters">
        <div>
          <div className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">From</div>
          <Input type="date" value={filters.start} onChange={(e) => setFilters({ ...filters, start: e.target.value })} data-testid="filter-start" />
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">To</div>
          <Input type="date" value={filters.end} onChange={(e) => setFilters({ ...filters, end: e.target.value })} data-testid="filter-end" />
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Project</div>
          <Select value={filters.project_id} onValueChange={(v) => setFilters({ ...filters, project_id: v })}>
            <SelectTrigger data-testid="filter-project"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All projects</SelectItem>
              {projects.map((p) => (<SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Status</div>
          <Select value={filters.status} onValueChange={(v) => setFilters({ ...filters, status: v })}>
            <SelectTrigger data-testid="filter-status"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {isAdmin && (
          <div>
            <div className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Scope</div>
            <Select value={filters.scope} onValueChange={(v) => setFilters({ ...filters, scope: v })}>
              <SelectTrigger data-testid="filter-scope"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="mine">My entries</SelectItem>
                <SelectItem value="all">All team</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between">
        <div className="text-sm text-gray-600">
          <span className="font-mono text-gray-900 font-semibold" data-testid="entries-count">{entries.length}</span> entries ·{" "}
          <span className="font-mono text-gray-900 font-semibold" data-testid="total-hours">{minutesToHM(total)}</span> total
        </div>
      </div>

      <div className="border border-gray-200 overflow-x-auto">
        <table className="w-full text-sm" data-testid="entries-table">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr className="text-left text-[10px] uppercase tracking-wider text-gray-500">
              <th className="px-4 py-3">Date</th>
              {filters.scope === "all" && <th className="px-4 py-3">Employee</th>}
              <th className="px-4 py-3">Project</th>
              <th className="px-4 py-3">Task</th>
              <th className="px-4 py-3">Start–End</th>
              <th className="px-4 py-3">Hours</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {entries.map((e) => (
              <tr key={e.id} className="border-b border-gray-100 row-hover" data-testid={`entry-row-${e.id}`}>
                <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">{new Date(e.start_at).toLocaleDateString()}</td>
                {filters.scope === "all" && <td className="px-4 py-3 whitespace-nowrap">{e.user_name}</td>}
                <td className="px-4 py-3 whitespace-nowrap">{e.project_name || <span className="text-gray-400">—</span>}</td>
                <td className="px-4 py-3">{e.task || <span className="text-gray-400">—</span>}</td>
                <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">
                  {new Date(e.start_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  {" – "}
                  {e.end_at ? new Date(e.end_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "…"}
                </td>
                <td className="px-4 py-3 font-mono">{minutesToHM(e.duration_minutes)}</td>
                <td className="px-4 py-3"><StatusPill status={e.status} /></td>
                <td className="px-4 py-3 text-right whitespace-nowrap">
                  <button onClick={() => { setEditing(e); setEditOpen(true); }} className="text-gray-400 hover:text-black mr-3" data-testid={`edit-entry-${e.id}`}>
                    <Pencil size={14} />
                  </button>
                  <button onClick={() => onDelete(e.id)} className="text-gray-400 hover:text-[#ff3b30]" data-testid={`delete-entry-${e.id}`}>
                    <Trash2 size={14} />
                  </button>
                </td>
              </tr>
            ))}
            {entries.length === 0 && (
              <tr><td colSpan={8} className="px-4 py-10 text-center text-gray-500" data-testid="empty-entries">No entries match these filters.</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <EditEntryDialog
        entry={editing}
        projects={projects}
        open={editOpen}
        onOpenChange={setEditOpen}
        onUpdated={load}
      />
    </div>
  );
}
