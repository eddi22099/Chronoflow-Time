import React, { useEffect, useState } from "react";
import api, { minutesToHM, formatApiError } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { StatusPill } from "@/pages/Dashboard";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid,
} from "recharts";
import { Check, X, CheckCheck, XCircle } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";

function Tile({ label, value, hint, testId, accent }) {
  return (
    <div className="border border-gray-200 p-5" data-testid={testId}>
      <div className="text-[10px] uppercase tracking-[0.2em] font-bold text-gray-500">{label}</div>
      <div className="flex items-baseline gap-2 mt-2">
        <div className="font-heading text-3xl lg:text-4xl font-black tracking-tighter">{value}</div>
        {accent && <span className="text-xs font-mono" style={{ color: accent.color }}>{accent.label}</span>}
      </div>
      {hint && <div className="text-xs text-gray-500 mt-1 font-mono">{hint}</div>}
    </div>
  );
}

export default function Admin() {
  const [stats, setStats] = useState(null);
  const [pending, setPending] = useState([]);
  const [selected, setSelected] = useState(new Set());

  const load = async () => {
    const [s, p] = await Promise.all([
      api.get("/dashboard/admin"),
      api.get("/entries", { params: { scope: "all", status: "pending" } }),
    ]);
    setStats(s.data);
    setPending(p.data);
    setSelected(new Set());
  };

  useEffect(() => { load(); }, []);

  const setStatus = async (id, status) => {
    try {
      await api.patch(`/entries/${id}/status`, { status });
      toast.success(`Entry ${status}`);
      load();
    } catch (err) {
      toast.error(formatApiError(err));
    }
  };

  const toggleOne = (id) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleAll = () => {
    if (selected.size === pending.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(pending.map((e) => e.id)));
    }
  };

  const bulkUpdate = async (status) => {
    const ids = Array.from(selected);
    if (ids.length === 0) return;
    try {
      const { data } = await api.post("/entries/bulk-status", { ids, status });
      toast.success(`${data.updated} entries ${status}`);
      load();
    } catch (err) {
      toast.error(formatApiError(err));
    }
  };

  return (
    <div className="space-y-8" data-testid="admin-page">
      <header>
        <div className="text-xs uppercase tracking-[0.2em] text-gray-500">Command Center</div>
        <h1 className="font-heading text-4xl md:text-5xl font-black tracking-tighter mt-1">Admin Dashboard</h1>
        <p className="text-gray-600 mt-2">Team analytics, approvals, and the pulse of every billable minute.</p>
      </header>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Tile label="Team members" value={stats?.total_employees ?? 0} testId="admin-stat-employees" />
        <Tile label="Active today" value={stats?.active_today_count ?? 0} testId="admin-stat-active" accent={{ label: "now", color: "#34c759" }} />
        <Tile label="Pending approvals" value={stats?.pending_count ?? 0} testId="admin-stat-pending" accent={stats?.pending_count ? { label: "review", color: "#ff3b30" } : null} />
        <Tile label="Team hours · week" value={minutesToHM(stats?.week_minutes)} testId="admin-stat-week" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <section className="lg:col-span-2 border border-gray-200 p-6">
          <div className="text-[10px] uppercase tracking-[0.2em] font-bold text-gray-500">Team Activity</div>
          <h3 className="font-heading text-xl font-bold mt-1 mb-4">Hours logged · last 7 days</h3>
          <div className="h-64" data-testid="admin-chart">
            {stats?.chart && (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.chart.map((c) => ({ ...c, hours: +(c.minutes / 60).toFixed(2) }))}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                  <XAxis dataKey="day" tick={{ fill: "#6b7280", fontSize: 12 }} axisLine={{ stroke: "#e5e7eb" }} tickLine={false} />
                  <YAxis tick={{ fill: "#6b7280", fontSize: 12 }} axisLine={{ stroke: "#e5e7eb" }} tickLine={false} />
                  <Tooltip cursor={{ fill: "rgba(0,0,0,0.04)" }} contentStyle={{ borderRadius: 4, border: "1px solid #e5e7eb", fontSize: 12 }} />
                  <Bar dataKey="hours" fill="#002fa7" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </section>

        <section className="border border-gray-200 p-6">
          <div className="text-[10px] uppercase tracking-[0.2em] font-bold text-gray-500">Leaderboard</div>
          <h3 className="font-heading text-xl font-bold mt-1">Top performers</h3>
          <div className="mt-4 space-y-3" data-testid="top-performers">
            {(stats?.top_performers || []).map((u, i) => (
              <div key={u.user_id} className="flex items-center justify-between border-b border-gray-100 pb-2 last:border-0">
                <div className="flex items-center gap-3">
                  <div className="font-heading font-black text-2xl w-7 text-gray-300">{i + 1}</div>
                  <div className="text-sm font-medium">{u.name || "—"}</div>
                </div>
                <div className="font-mono text-sm">{minutesToHM(u.minutes)}</div>
              </div>
            ))}
            {(!stats?.top_performers || stats.top_performers.length === 0) && (
              <div className="text-sm text-gray-500">No activity yet this week.</div>
            )}
          </div>
        </section>
      </div>

      <section>
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-[10px] uppercase tracking-[0.2em] font-bold text-gray-500">Approvals</div>
            <h3 className="font-heading text-xl font-bold mt-1">Pending time entries</h3>
          </div>
          {selected.size > 0 && (
            <div className="flex items-center gap-2" data-testid="bulk-actions">
              <span className="text-xs font-mono text-gray-600" data-testid="bulk-selected-count">{selected.size} selected</span>
              <Button size="sm" onClick={() => bulkUpdate("approved")} data-testid="bulk-approve-btn" className="bg-[#34c759] hover:bg-green-700 text-white h-8">
                <CheckCheck size={14} className="mr-1" /> Approve selected
              </Button>
              <Button size="sm" variant="outline" onClick={() => bulkUpdate("rejected")} data-testid="bulk-reject-btn" className="border-gray-300 text-gray-700 h-8">
                <XCircle size={14} className="mr-1" /> Reject selected
              </Button>
            </div>
          )}
        </div>
        <div className="border border-gray-200 overflow-x-auto">
          <table className="w-full text-sm" data-testid="approvals-table">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr className="text-left text-[10px] uppercase tracking-wider text-gray-500">
                <th className="px-4 py-3 w-10">
                  <Checkbox
                    checked={pending.length > 0 && selected.size === pending.length}
                    onCheckedChange={toggleAll}
                    data-testid="bulk-select-all"
                    disabled={pending.length === 0}
                  />
                </th>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Employee</th>
                <th className="px-4 py-3">Project</th>
                <th className="px-4 py-3">Task</th>
                <th className="px-4 py-3">Hours</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {pending.map((e) => (
                <tr key={e.id} className="border-b border-gray-100 row-hover" data-testid={`approval-row-${e.id}`}>
                  <td className="px-4 py-3">
                    <Checkbox
                      checked={selected.has(e.id)}
                      onCheckedChange={() => toggleOne(e.id)}
                      data-testid={`select-${e.id}`}
                    />
                  </td>
                  <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">{new Date(e.start_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{e.user_name}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{e.project_name || <span className="text-gray-400">—</span>}</td>
                  <td className="px-4 py-3">{e.task || <span className="text-gray-400">—</span>}</td>
                  <td className="px-4 py-3 font-mono">{minutesToHM(e.duration_minutes)}</td>
                  <td className="px-4 py-3"><StatusPill status={e.status} /></td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <Button size="sm" onClick={() => setStatus(e.id, "approved")} data-testid={`approve-${e.id}`} className="bg-[#34c759] hover:bg-green-700 text-white h-8 mr-1.5">
                      <Check size={14} className="mr-1" /> Approve
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setStatus(e.id, "rejected")} data-testid={`reject-${e.id}`} className="border-gray-300 text-gray-700 h-8">
                      <X size={14} className="mr-1" /> Reject
                    </Button>
                  </td>
                </tr>
              ))}
              {pending.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-10 text-center text-gray-500" data-testid="empty-approvals">All caught up — no pending entries.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-[10px] uppercase tracking-[0.2em] font-bold text-gray-500">Distribution</div>
            <h3 className="font-heading text-xl font-bold mt-1">Hours by project</h3>
          </div>
        </div>
        <div className="border border-gray-200">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr className="text-left text-[10px] uppercase tracking-wider text-gray-500">
                <th className="px-4 py-3">Project</th>
                <th className="px-4 py-3">Hours</th>
              </tr>
            </thead>
            <tbody>
              {(stats?.by_project || []).map((row) => (
                <tr key={row.project} className="border-b border-gray-100" data-testid={`project-row-${row.project}`}>
                  <td className="px-4 py-3">{row.project}</td>
                  <td className="px-4 py-3 font-mono">{minutesToHM(row.minutes)}</td>
                </tr>
              ))}
              {(!stats?.by_project || stats.by_project.length === 0) && (
                <tr><td colSpan={2} className="px-4 py-8 text-center text-gray-500">No data.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
