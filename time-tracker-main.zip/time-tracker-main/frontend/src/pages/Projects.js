import React, { useEffect, useState } from "react";
import api, { formatApiError } from "@/lib/api";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { Trash2, FolderKanban } from "lucide-react";

const COLORS = ["#111827", "#002fa7", "#34c759", "#ffcc00", "#ff3b30", "#a855f7", "#0ea5e9"];

export default function Projects() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [projects, setProjects] = useState([]);
  const [form, setForm] = useState({ name: "", client: "", color: COLORS[0], default_rate: "" });
  const [loading, setLoading] = useState(false);

  const load = async () => {
    const { data } = await api.get("/projects");
    setProjects(data);
  };
  useEffect(() => { load(); }, []);

  const create = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post("/projects", {
        ...form,
        default_rate: form.default_rate ? parseFloat(form.default_rate) : 0,
      });
      setForm({ name: "", client: "", color: COLORS[0], default_rate: "" });
      toast.success("Project created");
      load();
    } catch (err) {
      toast.error(formatApiError(err));
    } finally { setLoading(false); }
  };

  const del = async (id) => {
    if (!window.confirm("Delete this project?")) return;
    try {
      await api.delete(`/projects/${id}`);
      load();
    } catch (err) {
      toast.error(formatApiError(err));
    }
  };

  return (
    <div className="space-y-6" data-testid="projects-page">
      <header>
        <div className="text-xs uppercase tracking-[0.2em] text-gray-500">Catalog</div>
        <h1 className="font-heading text-4xl md:text-5xl font-black tracking-tighter mt-1">Projects</h1>
        <p className="text-gray-600 mt-2">Organize work into projects so hours land in the right buckets.</p>
      </header>

      {isAdmin && (
        <form onSubmit={create} className="border border-gray-200 p-5 grid grid-cols-1 md:grid-cols-4 gap-3 items-end" data-testid="project-create-form">
          <div className="md:col-span-2">
            <Label>Name</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required placeholder="e.g. Apollo Mobile App" data-testid="project-name-input" />
          </div>
          <div>
            <Label>Client</Label>
            <Input value={form.client} onChange={(e) => setForm({ ...form, client: e.target.value })} placeholder="Optional" data-testid="project-client-input" />
          </div>
          <div>
            <Label>Default rate ($ / hour)</Label>
            <Input type="number" min="0" step="0.01" value={form.default_rate} onChange={(e) => setForm({ ...form, default_rate: e.target.value })} placeholder="e.g. 75" data-testid="project-rate-input" />
          </div>
          <div>
            <Label>Color</Label>
            <div className="flex gap-2 mt-2 flex-wrap" data-testid="project-color-picker">
              {COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setForm({ ...form, color: c })}
                  className={`w-7 h-7 rounded-full border-2 ${form.color === c ? "border-black" : "border-transparent"}`}
                  style={{ background: c }}
                  data-testid={`color-${c}`}
                />
              ))}
            </div>
          </div>
          <div className="md:col-span-4">
            <Button type="submit" disabled={loading} className="bg-black hover:bg-gray-800 text-white" data-testid="project-create-btn">
              {loading ? "Creating…" : "Create project"}
            </Button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {projects.map((p) => (
          <div key={p.id} className="border border-gray-200 p-5 transition-all hover:-translate-y-0.5 hover:shadow-sm" data-testid={`project-card-${p.id}`}>
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full" style={{ background: p.color }} />
                <div>
                  <div className="font-heading text-lg font-bold tracking-tight">{p.name}</div>
                  <div className="text-xs text-gray-500 font-mono">{p.client || "—"}{p.default_rate ? ` · $${p.default_rate}/h` : ""}</div>
                </div>
              </div>
              {isAdmin && (
                <button onClick={() => del(p.id)} className="text-gray-400 hover:text-[#ff3b30]" data-testid={`delete-project-${p.id}`}>
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          </div>
        ))}
        {projects.length === 0 && (
          <div className="md:col-span-3 border border-dashed border-gray-300 p-10 text-center" data-testid="empty-projects">
            <FolderKanban className="mx-auto text-gray-400" size={28} />
            <div className="font-heading text-lg font-bold mt-3">No projects yet</div>
            <p className="text-sm text-gray-500 mt-1">{isAdmin ? "Create one above to begin categorizing time." : "Ask an admin to create projects."}</p>
          </div>
        )}
      </div>
    </div>
  );
}
