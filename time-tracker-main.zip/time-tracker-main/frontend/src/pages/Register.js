import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function Register() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const res = await register(email, password, name);
    setLoading(false);
    if (res.ok) {
      toast.success("Account created");
      navigate("/dashboard");
    } else {
      toast.error(res.error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-white p-8">
      <div className="w-full max-w-md">
        <div className="font-heading text-2xl font-black mb-8">
          CHRONO<span className="text-[#34c759]">FLOW</span>
        </div>
        <div className="text-xs uppercase tracking-[0.2em] text-gray-500">Get started</div>
        <h2 className="font-heading text-3xl sm:text-4xl font-black tracking-tighter mt-1">Create your account</h2>
        <form onSubmit={onSubmit} className="mt-8 space-y-5" data-testid="register-form">
          <div className="space-y-2">
            <Label htmlFor="name">Full name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required data-testid="register-name-input" className="h-11" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required data-testid="register-email-input" className="h-11" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password (min 6 chars)</Label>
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} data-testid="register-password-input" className="h-11" />
          </div>
          <Button type="submit" disabled={loading} data-testid="register-submit-btn" className="w-full h-11 bg-black hover:bg-gray-800 text-white">
            {loading ? "Creating…" : "Create account"}
          </Button>
        </form>
        <div className="mt-6 text-sm text-gray-600">
          Already have an account?{" "}
          <Link to="/login" className="font-semibold underline underline-offset-4" data-testid="link-login">
            Sign in
          </Link>
        </div>
      </div>
    </div>
  );
}
