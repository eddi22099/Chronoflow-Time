"""Tests for ChronoFlow new features: inline edit (PATCH /entries/{id}) and bulk-status."""
import os
import pytest
import requests
from datetime import datetime, timezone, timedelta

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://employee-time-log-3.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN = {"email": "admin@chronoflow.com", "password": "Admin@123"}
EMP = {"email": "employee@chronoflow.com", "password": "Employee@123"}


def _login(creds):
    r = requests.post(f"{API}/auth/login", json=creds, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["token"]


def _h(tok):
    return {"Authorization": f"Bearer {tok}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def admin_token():
    return _login(ADMIN)


@pytest.fixture(scope="module")
def emp_token():
    return _login(EMP)


@pytest.fixture(scope="module")
def project_id(admin_token):
    r = requests.get(f"{API}/projects", headers=_h(admin_token), timeout=20)
    assert r.status_code == 200
    projects = r.json()
    if projects:
        return projects[0]["id"]
    r = requests.post(f"{API}/projects", headers=_h(admin_token), json={"name": "TEST_Project"}, timeout=20)
    return r.json()["id"]


def _create_entry(token, task="TEST_task", project_id=None, hours_offset=2):
    now = datetime.now(timezone.utc)
    end = now - timedelta(hours=1)
    start = end - timedelta(hours=hours_offset)
    body = {
        "project_id": project_id,
        "task": task,
        "notes": "TEST_note",
        "start_at": start.isoformat(),
        "end_at": end.isoformat(),
    }
    r = requests.post(f"{API}/entries", headers=_h(token), json=body, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()


# ------ PATCH /entries/{id} ------
class TestPatchEntry:
    def test_owner_updates_task_and_notes(self, emp_token):
        e = _create_entry(emp_token, task="orig")
        r = requests.patch(f"{API}/entries/{e['id']}", headers=_h(emp_token),
                           json={"task": "updated_task", "notes": "updated_notes"}, timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["task"] == "updated_task"
        assert d["notes"] == "updated_notes"
        # verify persisted via GET list
        g = requests.get(f"{API}/entries", headers=_h(emp_token), timeout=20)
        assert any(x["id"] == e["id"] and x["task"] == "updated_task" for x in g.json())

    def test_owner_updates_times_recomputes_duration(self, emp_token):
        e = _create_entry(emp_token, hours_offset=1)
        start = datetime.now(timezone.utc) - timedelta(hours=5)
        end = start + timedelta(hours=3)  # 180 min
        r = requests.patch(f"{API}/entries/{e['id']}", headers=_h(emp_token),
                           json={"start_at": start.isoformat(), "end_at": end.isoformat()}, timeout=20)
        assert r.status_code == 200
        assert r.json()["duration_minutes"] == 180

    def test_clear_project_id_with_empty_string(self, emp_token, project_id):
        e = _create_entry(emp_token, project_id=project_id)
        r = requests.patch(f"{API}/entries/{e['id']}", headers=_h(emp_token),
                           json={"project_id": ""}, timeout=20)
        assert r.status_code == 200
        d = r.json()
        assert d["project_id"] in (None, "")
        assert d["project_name"] == ""

    def test_set_project_id(self, emp_token, project_id):
        e = _create_entry(emp_token)
        r = requests.patch(f"{API}/entries/{e['id']}", headers=_h(emp_token),
                           json={"project_id": project_id}, timeout=20)
        assert r.status_code == 200
        assert r.json()["project_id"] == project_id

    def test_non_owner_employee_gets_403(self, emp_token, admin_token):
        # admin creates entry as themselves, employee tries to patch it
        a = _create_entry(admin_token, task="admin_entry")
        r = requests.patch(f"{API}/entries/{a['id']}", headers=_h(emp_token),
                           json={"task": "hacked"}, timeout=20)
        assert r.status_code == 403

    def test_admin_can_edit_any_entry(self, admin_token, emp_token):
        e = _create_entry(emp_token, task="emp_owned")
        r = requests.patch(f"{API}/entries/{e['id']}", headers=_h(admin_token),
                           json={"task": "admin_edited"}, timeout=20)
        assert r.status_code == 200
        assert r.json()["task"] == "admin_edited"

    def test_not_found_returns_404(self, emp_token):
        r = requests.patch(f"{API}/entries/nonexistent-id-xyz", headers=_h(emp_token),
                           json={"task": "x"}, timeout=20)
        assert r.status_code == 404


# ------ POST /entries/bulk-status ------
class TestBulkStatus:
    def test_admin_bulk_approve(self, admin_token, emp_token):
        ids = [_create_entry(emp_token, task=f"TEST_bulk_{i}")["id"] for i in range(3)]
        r = requests.post(f"{API}/entries/bulk-status", headers=_h(admin_token),
                          json={"ids": ids, "status": "approved"}, timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert "updated" in d
        assert d["updated"] == 3
        # verify persistence: each entry now approved
        g = requests.get(f"{API}/entries", headers=_h(admin_token),
                        params={"scope": "all"}, timeout=20).json()
        statuses = {x["id"]: x["status"] for x in g}
        for i in ids:
            assert statuses.get(i) == "approved"

    def test_admin_bulk_reject(self, admin_token, emp_token):
        ids = [_create_entry(emp_token, task="TEST_rej")["id"] for _ in range(2)]
        r = requests.post(f"{API}/entries/bulk-status", headers=_h(admin_token),
                          json={"ids": ids, "status": "rejected"}, timeout=20)
        assert r.status_code == 200
        assert r.json()["updated"] == 2

    def test_empty_ids_returns_zero(self, admin_token):
        r = requests.post(f"{API}/entries/bulk-status", headers=_h(admin_token),
                          json={"ids": [], "status": "approved"}, timeout=20)
        assert r.status_code == 200
        assert r.json()["updated"] == 0

    def test_employee_forbidden(self, emp_token):
        r = requests.post(f"{API}/entries/bulk-status", headers=_h(emp_token),
                          json={"ids": ["any"], "status": "approved"}, timeout=20)
        assert r.status_code == 403

    def test_invalid_status_returns_422(self, admin_token):
        r = requests.post(f"{API}/entries/bulk-status", headers=_h(admin_token),
                          json={"ids": ["x"], "status": "weird"}, timeout=20)
        assert r.status_code == 422


# ------ Regression: single approve/reject still works ------
class TestSingleStatusRegression:
    def test_admin_approve_single(self, admin_token, emp_token):
        e = _create_entry(emp_token, task="TEST_single_approve")
        r = requests.patch(f"{API}/entries/{e['id']}/status", headers=_h(admin_token),
                           json={"status": "approved"}, timeout=20)
        assert r.status_code == 200
        assert r.json()["status"] == "approved"

    def test_admin_reject_single(self, admin_token, emp_token):
        e = _create_entry(emp_token, task="TEST_single_reject")
        r = requests.patch(f"{API}/entries/{e['id']}/status", headers=_h(admin_token),
                           json={"status": "rejected"}, timeout=20)
        assert r.status_code == 200
        assert r.json()["status"] == "rejected"


# ------ Regression: login ------
def test_admin_login():
    r = requests.post(f"{API}/auth/login", json=ADMIN, timeout=20)
    assert r.status_code == 200
    assert "token" in r.json()
    assert r.json()["user"]["role"] == "admin"
