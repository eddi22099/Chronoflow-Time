"""Tests for ChronoFlow invoicing, billable, rate priority, clients, user/project updates."""
import os
import pytest
import requests
from datetime import datetime, timezone, timedelta

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://employee-time-log-3.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN = {"email": "admin@chronoflow.com", "password": "Admin@123"}
EMP = {"email": "employee@chronoflow.com", "password": "Employee@123"}


def _login(creds):
    r = requests.post(f"{API}/auth/login", json=creds, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["token"]


def _h(tok):
    return {"Authorization": f"Bearer {tok}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def admin_token():
    return _login(ADMIN)


@pytest.fixture(scope="module")
def emp_token():
    return _login(EMP)


@pytest.fixture(scope="module")
def emp_user_id(admin_token):
    r = requests.get(f"{API}/users", headers=_h(admin_token), timeout=20)
    for u in r.json():
        if u["email"] == "employee@chronoflow.com":
            return u["id"]
    pytest.skip("employee user not seeded")


def _create_project(admin_token, name, client="TEST_Client_A", default_rate=0):
    r = requests.post(f"{API}/projects", headers=_h(admin_token),
                      json={"name": name, "client": client, "default_rate": default_rate}, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()


def _create_approved_billable_entry(emp_token, admin_token, project_id, hours=2, billable=True):
    now = datetime.now(timezone.utc)
    end = now - timedelta(hours=1)
    start = end - timedelta(hours=hours)
    r = requests.post(f"{API}/entries", headers=_h(emp_token),
                      json={"project_id": project_id, "task": "TEST_inv_task",
                            "start_at": start.isoformat(), "end_at": end.isoformat(),
                            "billable": billable}, timeout=20)
    assert r.status_code == 200, r.text
    entry = r.json()
    # Approve via admin
    r2 = requests.patch(f"{API}/entries/{entry['id']}/status", headers=_h(admin_token),
                       json={"status": "approved"}, timeout=20)
    assert r2.status_code == 200
    return entry


# ----------- PATCH /users/{id} -----------
class TestUserUpdate:
    def test_admin_sets_hourly_rate(self, admin_token, emp_user_id):
        r = requests.patch(f"{API}/users/{emp_user_id}", headers=_h(admin_token),
                           json={"hourly_rate": 75.5}, timeout=20)
        assert r.status_code == 200, r.text
        assert r.json()["hourly_rate"] == 75.5
        # verify via GET
        g = requests.get(f"{API}/users", headers=_h(admin_token), timeout=20).json()
        emp = next(u for u in g if u["id"] == emp_user_id)
        assert emp["hourly_rate"] == 75.5

    def test_employee_cannot_patch_user(self, emp_token, emp_user_id):
        r = requests.patch(f"{API}/users/{emp_user_id}", headers=_h(emp_token),
                           json={"hourly_rate": 200}, timeout=20)
        assert r.status_code == 403


# ----------- PATCH /projects/{id} -----------
class TestProjectUpdate:
    def test_admin_updates_default_rate(self, admin_token):
        p = _create_project(admin_token, "TEST_ProjUpdate", "TEST_Client_U", 10)
        r = requests.patch(f"{API}/projects/{p['id']}", headers=_h(admin_token),
                           json={"default_rate": 99.99}, timeout=20)
        assert r.status_code == 200
        assert r.json()["default_rate"] == 99.99

    def test_employee_cannot_patch_project(self, emp_token, admin_token):
        p = _create_project(admin_token, "TEST_ProjBlock", "TEST_Client_B", 10)
        r = requests.patch(f"{API}/projects/{p['id']}", headers=_h(emp_token),
                           json={"default_rate": 1}, timeout=20)
        assert r.status_code == 403


# ----------- GET /clients -----------
class TestClients:
    def test_clients_dedup(self, admin_token):
        _create_project(admin_token, "TEST_C1", "TEST_DedupClient", 10)
        _create_project(admin_token, "TEST_C2", "TEST_DedupClient", 20)
        r = requests.get(f"{API}/clients", headers=_h(admin_token), timeout=20)
        assert r.status_code == 200
        names = [c["name"] for c in r.json()]
        # dedup: one entry per name
        assert names.count("TEST_DedupClient") == 1
        # ensure projects under it >= 2
        client = next(c for c in r.json() if c["name"] == "TEST_DedupClient")
        assert len(client["projects"]) >= 2


# ----------- Entry billable -----------
class TestEntryBillable:
    def test_create_with_billable_false(self, emp_token):
        now = datetime.now(timezone.utc)
        end = now - timedelta(hours=1)
        start = end - timedelta(hours=1)
        r = requests.post(f"{API}/entries", headers=_h(emp_token),
                          json={"task": "TEST_nb", "start_at": start.isoformat(),
                                "end_at": end.isoformat(), "billable": False}, timeout=20)
        assert r.status_code == 200
        assert r.json()["billable"] is False

    def test_patch_billable_toggle(self, emp_token):
        now = datetime.now(timezone.utc)
        end = now - timedelta(hours=1)
        start = end - timedelta(hours=1)
        r = requests.post(f"{API}/entries", headers=_h(emp_token),
                          json={"task": "TEST_pb", "start_at": start.isoformat(),
                                "end_at": end.isoformat(), "billable": False}, timeout=20)
        eid = r.json()["id"]
        r2 = requests.patch(f"{API}/entries/{eid}", headers=_h(emp_token),
                           json={"billable": True}, timeout=20)
        assert r2.status_code == 200
        assert r2.json()["billable"] is True


# ----------- Invoice preview/generate + rate priority -----------
class TestInvoice:
    def test_preview_invalid_scope_field(self, admin_token):
        # scope=project but missing project_id
        r = requests.post(f"{API}/invoices/preview", headers=_h(admin_token),
                          json={"scope": "project"}, timeout=20)
        assert r.status_code == 400

    def test_preview_client_missing_field(self, admin_token):
        r = requests.post(f"{API}/invoices/preview", headers=_h(admin_token),
                          json={"scope": "client"}, timeout=20)
        assert r.status_code == 400

    def test_preview_invalid_scope_value(self, admin_token):
        # Pydantic Literal rejects -> 422
        r = requests.post(f"{API}/invoices/preview", headers=_h(admin_token),
                          json={"scope": "weird"}, timeout=20)
        assert r.status_code in (400, 422)

    def test_rate_priority_override_wins(self, admin_token, emp_token, emp_user_id):
        # Set employee rate
        requests.patch(f"{API}/users/{emp_user_id}", headers=_h(admin_token),
                       json={"hourly_rate": 50}, timeout=20)
        proj = _create_project(admin_token, "TEST_RP_Override", "TEST_RPClient_O", default_rate=30)
        _create_approved_billable_entry(emp_token, admin_token, proj["id"], hours=2)
        # Override should win
        r = requests.post(f"{API}/invoices/preview", headers=_h(admin_token),
                          json={"scope": "project", "project_id": proj["id"],
                                "rate_override": 100, "use_employee_rate": True}, timeout=20)
        assert r.status_code == 200, r.text
        data = r.json()
        assert len(data["line_items"]) >= 1
        assert all(li["rate"] == 100 for li in data["line_items"])

    def test_rate_priority_employee_over_project(self, admin_token, emp_token, emp_user_id):
        requests.patch(f"{API}/users/{emp_user_id}", headers=_h(admin_token),
                       json={"hourly_rate": 60}, timeout=20)
        proj = _create_project(admin_token, "TEST_RP_Emp", "TEST_RPClient_E", default_rate=25)
        _create_approved_billable_entry(emp_token, admin_token, proj["id"], hours=1)
        r = requests.post(f"{API}/invoices/preview", headers=_h(admin_token),
                          json={"scope": "project", "project_id": proj["id"],
                                "use_employee_rate": True}, timeout=20)
        assert r.status_code == 200
        data = r.json()
        assert len(data["line_items"]) >= 1
        # When use_employee_rate=True and employee rate > 0, it wins
        assert all(li["rate"] == 60 for li in data["line_items"])

    def test_rate_priority_project_default(self, admin_token, emp_token, emp_user_id):
        # Reset employee rate to 0 to ensure project default is used
        requests.patch(f"{API}/users/{emp_user_id}", headers=_h(admin_token),
                       json={"hourly_rate": 0}, timeout=20)
        proj = _create_project(admin_token, "TEST_RP_Proj", "TEST_RPClient_P", default_rate=42)
        _create_approved_billable_entry(emp_token, admin_token, proj["id"], hours=1)
        r = requests.post(f"{API}/invoices/preview", headers=_h(admin_token),
                          json={"scope": "project", "project_id": proj["id"]}, timeout=20)
        assert r.status_code == 200
        data = r.json()
        assert len(data["line_items"]) >= 1
        assert all(li["rate"] == 42 for li in data["line_items"])

    def test_only_approved_billable_included(self, admin_token, emp_token, emp_user_id):
        requests.patch(f"{API}/users/{emp_user_id}", headers=_h(admin_token),
                       json={"hourly_rate": 0}, timeout=20)
        proj = _create_project(admin_token, "TEST_Filter", "TEST_FilterClient", default_rate=20)

        # 1. approved billable -> included
        good = _create_approved_billable_entry(emp_token, admin_token, proj["id"], hours=2, billable=True)
        # 2. pending billable -> excluded
        now = datetime.now(timezone.utc)
        end = now - timedelta(hours=1); start = end - timedelta(hours=1)
        pending = requests.post(f"{API}/entries", headers=_h(emp_token),
                               json={"project_id": proj["id"], "task": "pending",
                                     "start_at": start.isoformat(), "end_at": end.isoformat(),
                                     "billable": True}, timeout=20).json()
        # 3. approved non-billable -> excluded
        end2 = now - timedelta(hours=4); start2 = end2 - timedelta(hours=1)
        nb = requests.post(f"{API}/entries", headers=_h(emp_token),
                          json={"project_id": proj["id"], "task": "nonbill",
                                "start_at": start2.isoformat(), "end_at": end2.isoformat(),
                                "billable": False}, timeout=20).json()
        requests.patch(f"{API}/entries/{nb['id']}/status", headers=_h(admin_token),
                       json={"status": "approved"}, timeout=20)

        r = requests.post(f"{API}/invoices/preview", headers=_h(admin_token),
                          json={"scope": "project", "project_id": proj["id"]}, timeout=20)
        assert r.status_code == 200
        ids_in_pdf_tasks = {li["task"] for li in r.json()["line_items"]}
        assert "TEST_inv_task" in ids_in_pdf_tasks or any("inv" in t for t in ids_in_pdf_tasks)
        assert "pending" not in ids_in_pdf_tasks
        assert "nonbill" not in ids_in_pdf_tasks

    def test_client_scope_aggregates(self, admin_token, emp_token, emp_user_id):
        requests.patch(f"{API}/users/{emp_user_id}", headers=_h(admin_token),
                       json={"hourly_rate": 0}, timeout=20)
        client_name = "TEST_AggClient"
        p1 = _create_project(admin_token, "TEST_AggP1", client_name, default_rate=10)
        p2 = _create_project(admin_token, "TEST_AggP2", client_name, default_rate=20)
        _create_approved_billable_entry(emp_token, admin_token, p1["id"], hours=1)
        _create_approved_billable_entry(emp_token, admin_token, p2["id"], hours=1)
        r = requests.post(f"{API}/invoices/preview", headers=_h(admin_token),
                          json={"scope": "client", "client": client_name}, timeout=20)
        assert r.status_code == 200
        data = r.json()
        projects = {li["project"] for li in data["line_items"]}
        assert "TEST_AggP1" in projects
        assert "TEST_AggP2" in projects

    def test_generate_returns_pdf(self, admin_token, emp_token, emp_user_id):
        proj = _create_project(admin_token, "TEST_PDFProj", "TEST_PDFClient", default_rate=15)
        _create_approved_billable_entry(emp_token, admin_token, proj["id"], hours=1)
        r = requests.post(f"{API}/invoices/generate", headers=_h(admin_token),
                          json={"scope": "project", "project_id": proj["id"]}, timeout=30)
        assert r.status_code == 200
        assert r.headers.get("content-type", "").startswith("application/pdf")
        assert r.content[:4] == b"%PDF"

    def test_generate_employee_forbidden(self, emp_token, admin_token):
        proj = _create_project(admin_token, "TEST_403Proj", "TEST_403Client", default_rate=15)
        r = requests.post(f"{API}/invoices/generate", headers=_h(emp_token),
                          json={"scope": "project", "project_id": proj["id"]}, timeout=20)
        assert r.status_code == 403
